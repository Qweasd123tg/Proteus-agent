from pathlib import Path
from collections import Counter, defaultdict
import ast, hashlib, json, re, subprocess, tomllib
import argparse
parser = argparse.ArgumentParser(description="Inventory source files without executing project code.")
parser.add_argument("root", type=Path, help="Extracted Proteus repository root")
parser.add_argument("--output", type=Path, default=Path("inventory.json"))
args = parser.parse_args()
root = args.root.resolve()
if not root.is_dir():
    parser.error("root must be an existing directory")
rows=[]; checks=[]; broken=[]; summaries=defaultdict(lambda:[0,0]); test_names=[]
for p in sorted(root.rglob('*')):
    if not p.is_file(): continue
    text=p.read_text(errors='replace'); rel=str(p.relative_to(root)); lines=text.splitlines()
    row={'path':rel,'bytes':p.stat().st_size,'lines':len(lines),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    rows.append(row);summaries[p.suffix or '[none]'][0]+=1;summaries[p.suffix or '[none]'][1]+=len(lines)
    if p.suffix=='.toml':
        try: tomllib.loads(text);checks.append({'path':rel,'check':'toml_parse','status':'pass'})
        except Exception as e: checks.append({'path':rel,'check':'toml_parse','status':'fail','error':str(e)})
    if p.suffix=='.py':
        try: ast.parse(text);checks.append({'path':rel,'check':'python_ast','status':'pass'})
        except Exception as e:checks.append({'path':rel,'check':'python_ast','status':'fail','error':str(e)})
    if p.suffix=='.sh':
        x=subprocess.run(['bash','-n',str(p)],text=True,capture_output=True)
        checks.append({'path':rel,'check':'bash_syntax','status':'pass' if x.returncode==0 else 'fail','error':x.stderr})
    if p.suffix=='.rs':
        for m in re.finditer(r'#\[(?:tokio::)?test(?:\([^\]]*\))?\]\s*(?:#\[[^\]]*\]\s*)*(?:pub\s+)?(?:async\s+)?fn\s+(\w+)',text):
            test_names.append({'path':rel,'line':text[:m.start()].count('\n')+1,'name':m.group(1)})
    if p.suffix=='.md':
        for m in re.finditer(r'\[[^\]\n]*\]\(([^)\s]+)(?:\s+"[^"]*")?\)',text):
            target=m.group(1).split('#')[0]
            if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:',target):continue
            import urllib.parse
            target=urllib.parse.unquote(target)
            if not (p.parent/target).exists(): broken.append({'path':rel,'line':text[:m.start()].count('\n')+1,'target':target})
data={'root':str(root),'files':rows,'summary':dict(summaries),'checks':checks,'test_functions_regex':test_names,'broken_local_links_candidates':broken}
args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2), encoding='utf-8')
print('ALL FILES SCANNED:',len(rows),'TOTAL LINES:',sum(r['lines'] for r in rows))
print('STATIC CHECKS:',dict(Counter((x['check'],x['status']) for x in checks)))
print('TEST FUNCTIONS FOUND:',len(test_names))
print('TEST DISTRIBUTION:',Counter('/'.join(x['path'].split('/')[:2]) for x in test_names))
print('BROKEN LINK CANDIDATES:',len(broken))
for x in broken[:35]:print(x)
print('CHECK FAILURES:')
for x in checks:
 if x['status']=='fail':print(x)
