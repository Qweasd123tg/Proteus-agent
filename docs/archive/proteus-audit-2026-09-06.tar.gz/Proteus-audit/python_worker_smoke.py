#!/usr/bin/env python3
"""Small independent smoke suite for the repository's real Python workers.
No Rust host is built; this is not the project's complete conformance suite.
"""
from __future__ import annotations
import argparse
import copy
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import threading
import uuid

class Peer:
    def __init__(self, script: Path, slot: str, module: str, version: str):
        self.slot, self.module = slot, module
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
        self.process = subprocess.Popen([sys.executable, '-B', str(script)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding='utf-8', env=env)
        self.queue: queue.Queue[str] = queue.Queue()
        def reader():
            assert self.process.stdout is not None
            for line in self.process.stdout:
                self.queue.put(line)
        self.thread = threading.Thread(target=reader, daemon=True)
        self.thread.start()
        self.send({'jsonrpc':'2.0', 'id':'h:1:0', 'method':'initialize', 'params':{
            'protocol_version':'v3', 'component_id':'audit-python', 'exports':[{
                'slot':slot, 'module_id':module, 'contract_version':version,
                'composition':'select_one', 'module_config':{}, 'host_features':[]}]}})
        result = self.read()
        assert result['id'] == 'h:1:0' and result['result']['component_id'] == 'audit-python', result
        assert result['result']['exports'][0]['module_id'] == module, result
        self.seq = 0
    def send(self, value: dict):
        assert self.process.stdin is not None
        self.process.stdin.write(json.dumps(value, separators=(',', ':')) + '\n')
        self.process.stdin.flush()
    def read(self) -> dict:
        try:
            return json.loads(self.queue.get(timeout=5))
        except queue.Empty as exc:
            raise TimeoutError('worker did not reply within five seconds') from exc
    def invoke(self, method: str, params: dict, wait: bool = True):
        self.seq += 1
        ident = f'h:1:{self.seq}'
        self.send({'jsonrpc':'2.0','id':ident,'method':method,'params':{
            'export':{'slot':self.slot,'module_id':self.module},
            'lineage':{'root_invocation_id':ident,'parent_invocation_id':None,'depth':0},
            'params':params}})
        return self.read() if wait else ident
    def close(self):
        if self.process.stdin and not self.process.stdin.closed:
            self.process.stdin.close()
        try:
            self.process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=2)
        for stream in (self.process.stdout, self.process.stderr):
            if stream:
                stream.close()
    def __enter__(self):
        return self
    def __exit__(self, *_):
        self.close()

def message(role: str, text: str, scope: str = 'conversation') -> dict:
    return {'id':str(uuid.uuid4()),'role':role,'phase':None,'name':'arbitrary-name',
        'tool_call_id':None,'metadata':None,'parts':[{'part_id':str(uuid.uuid4()),
        'provenance':'context_builder' if scope == 'request' else ('user' if role == 'User' else 'model'),
        'scope':scope,'payload':{'Text':{'text':text}}}]}

def run(root: Path) -> dict:
    passed = []
    base = {'task':{'text':'audit'},'model_ref':{},'messages':[],
        'token_estimate':None,'window_tokens':None,'config':None,'reason':None}
    with Peer(root/'examples/modules/compactor-process/compact.py','compactor','python_suffix','v3') as p:
        passed.append('compactor: actual subprocess v3 initialize/manifest')
        result = p.invoke('compact',base)
        assert result['result']['output']['changed'] is False, result
        passed.append('compactor: empty input unchanged')
        context = message('Developer','context','request')
        data = copy.deepcopy(base)
        data['messages'] = [context] + [message('User' if n%2 == 0 else 'Assistant',str(n)) for n in range(14)]
        result = p.invoke('compact',data)['result']['output']
        assert result['changed'] is True and len(result['messages']) == 5, result
        assert result['messages'][0] == context and result['messages'][1:] == data['messages'][-4:], result
        passed.append('compactor: request context preserved, last two user turns retained, names irrelevant')
        bad = copy.deepcopy(data)
        del bad['messages'][0]['parts'][0]['scope']
        result = p.invoke('compact',bad)
        assert 'error' in result and 'scope' in result['error']['message'], result
        passed.append('compactor: missing canonical scope rejected')
        bad = copy.deepcopy(base); bad['config'] = {'unknown':1}
        result = p.invoke('compact',bad)
        assert 'error' in result and 'unknown' in result['error']['message'], result
        passed.append('compactor: unknown strategy setting rejected')
        ids = {p.invoke('compact',base,wait=False) for _ in range(20)}
        responses = [p.read() for _ in ids]
        assert {r['id'] for r in responses} == ids and all('result' in r for r in responses), responses
        passed.append('compactor: twenty in-flight root requests all correlated correctly')
    with tempfile.TemporaryDirectory(prefix='proteus-audit-') as td:
        d = Path(td); (d/'src').mkdir(); (d/'src/a.txt').write_text('needle one\nneedle two\n',encoding='utf-8')
        (d/'other.txt').write_text('needle elsewhere\n',encoding='utf-8')
        with Peer(root/'examples/modules/search-process/search.py','search','python_rg','v1') as p:
            passed.append('search: actual subprocess v3 initialize/manifest')
            query = {'text':'needle','cwd':td,'max_results':1,'use_case':'audit','starts_with':['src/'],'ends_with':['.txt']}
            result = p.invoke('search',query)['result']['chunks']
            assert len(result) == 1 and result[0]['path'] == 'src/a.txt' and 'needle' in result[0]['content'], result
            passed.append('search: real ripgrep, prefix/suffix filtering and max_results')
            query['max_results'] = 0
            result = p.invoke('search',query)['result']['chunks']
            assert result == [], result
            passed.append('search: zero max_results returns empty')
    return {'scope':'Actual Python worker subprocesses and real ripgrep only; not Rust conformance or live LLM',
            'passed':passed,'passed_count':len(passed),'rust_tests_run':False}

if __name__ == '__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('root', type=Path)
    ap.add_argument('--output', type=Path)
    args=ap.parse_args()
    report=run(args.root.resolve())
    output=json.dumps(report,indent=2)
    if args.output:
        args.output.write_text(output+'\n',encoding='utf-8')
    print(output)
