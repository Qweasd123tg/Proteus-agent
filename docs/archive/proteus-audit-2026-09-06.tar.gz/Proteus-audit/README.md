# Материалы разбора Proteus

Дата: 2026-09-06. Исходный архив не изменялся и в этот комплект повторно не включён.

Начните с `Proteus-review.md`. Восемь находок статические: они не выдаются за выполненные Rust/browser-тесты.

- `findings.json`: приоритеты, статус проверки, точные пути и строки.
- `evidence/source-excerpts.md`: соответствующие фрагменты исходников.
- `inventory.json`: 592 файла, хеши, статистика, результаты синтаксических проверок.
- `inventory.py`: переносимый вариант скрипта инвентаризации (Python 3.11+, bash).
- `python_worker_smoke.py`: выполненный smoke actual Python workers (Python 3 + rg).
- `evidence/python-smoke.json`: 9 прошедших проверок, Rust tests не запускались.
- `proposed-cancellation.patch`: минимальное предложение для F01, не применённое и не скомпилированное.
- `evidence/verification.json`: итоговая проверка комплекта и неизменности исходников.

Команды из распакованного комплекта:

```bash
python -B inventory.py /path/to/Proteus-agent-main --output fresh-inventory.json
python -B python_worker_smoke.py /path/to/Proteus-agent-main --output fresh-smoke.json
```

Исходный inventory был создан скриптом с фиксированными путями этой среды. Включённая переносимая версия меняет только ввод root/output. Кандидаты сломанных Markdown-ссылок требуют ручной проверки; число найденных тестов не является test coverage.

Предложенный patch следует проверять на своей ветке вместе с детерминированной regression-проверкой cancellation, форматированием и Rust gate. Успешный dry-run применения patch не равен успешной компиляции.
