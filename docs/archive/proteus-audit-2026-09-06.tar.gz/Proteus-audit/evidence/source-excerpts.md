# Фрагменты исходников, подтверждающие находки

Это точные фрагменты из предоставленного ZIP, а не результаты исполнения.
Номера слева соответствуют исходным файлам. Все Rust/browser-находки имеют статическую верификацию.

## F01 · CancellationToken: потеря уведомления между проверкой флага и созданием Notified

### `crates/proteus-contracts/src/contracts/tool.rs:75–88`

```text
  75      pub fn cancel(&self) {
  76          cancel_state(&self.inner);
  77      }
  78  
  79      pub fn is_cancelled(&self) -> bool {
  80          self.inner.cancelled.load(Ordering::SeqCst)
  81      }
  82  
  83      pub async fn cancelled(&self) {
  84          if self.is_cancelled() {
  85              return;
  86          }
  87          self.inner.notify.notified().await;
  88      }
```

### `crates/proteus-contracts/src/contracts/tool.rs:113–125`

```text
 113  fn cancel_state(state: &Arc<CancellationState>) {
 114      if state.cancelled.swap(true, Ordering::SeqCst) {
 115          return;
 116      }
 117      state.notify.notify_waiters();
 118      let children = {
 119          let mut children = state
 120              .children
 121              .lock()
 122              .unwrap_or_else(|poisoned| poisoned.into_inner());
 123          std::mem::take(&mut *children)
 124      };
 125      for child in children {
```

## F02 · Web-клиент передаёт сохранённый токен на origin, выбранный query-параметром

### `clients/web/src/api.rs:10–55`

```text
  10  const DEFAULT_APP_SERVER_ORIGIN: &str = "http://127.0.0.1:8787";
  11  const DEFAULT_INSPECTOR_ORIGIN: &str = "http://127.0.0.1:1421";
  12  const SERVER_QUERY_KEY: &str = "server";
  13  const INSPECTOR_QUERY_KEY: &str = "inspector";
  14  const SESSION_QUERY_KEY: &str = "token";
  15  const SERVER_STORAGE_KEY: &str = "proteus.appServerOrigin";
  16  const INSPECTOR_STORAGE_KEY: &str = "proteus.inspectorOrigin";
  17  const SESSION_STORAGE_KEY: &str = "proteus.sessionToken";
  18  
  19  thread_local! {
  20      static APP_SERVER_ORIGIN: RefCell<String> = RefCell::new(DEFAULT_APP_SERVER_ORIGIN.to_owned());
  21      static INSPECTOR_ORIGIN: RefCell<String> = RefCell::new(DEFAULT_INSPECTOR_ORIGIN.to_owned());
  22      static SESSION_TOKEN: RefCell<SessionToken> = RefCell::new(SessionToken::missing());
  23  }
  24  
  25  pub(crate) fn load_session_token() -> Result<SessionToken, String> {
  26      load_app_server_origin()?;
  27      load_inspector_origin()?;
  28      let token = if let Some(token) = query_session_token() {
  29          persist_session_token(&token)?;
  30          token
  31      } else if let Some(storage) = session_storage()? {
  32          if let Some(value) = storage.get_item(SESSION_STORAGE_KEY).map_err(js_error)? {
  33              SessionToken::new(value)
  34          } else {
  35              SessionToken::missing()
  36          }
  37      } else {
  38          SessionToken::missing()
  39      };
  40  
  41      SESSION_TOKEN.with(|stored| *stored.borrow_mut() = token.clone());
  42      Ok(token)
  43  }
  44  
  45  pub(crate) fn event_stream_url() -> String {
  46      let token = current_session_token();
  47      let origin = app_server_origin();
  48      match token.as_deref() {
  49          Some(token) => format!(
  50              "{origin}/events?{}={}",
  51              SESSION_QUERY_KEY,
  52              encode_uri_component(token)
  53          ),
  54          None => format!("{origin}/events"),
  55      }
```

### `clients/web/src/api.rs:145–199`

```text
 145  fn load_app_server_origin() -> Result<(), String> {
 146      let origin = if let Some(origin) = query_app_server_origin() {
 147          persist_app_server_origin(&origin)?;
 148          origin
 149      } else if let Some(storage) = session_storage()? {
 150          storage
 151              .get_item(SERVER_STORAGE_KEY)
 152              .map_err(js_error)?
 153              .map(normalize_app_server_origin)
 154              .unwrap_or_else(|| DEFAULT_APP_SERVER_ORIGIN.to_owned())
 155      } else {
 156          DEFAULT_APP_SERVER_ORIGIN.to_owned()
 157      };
 158  
 159      APP_SERVER_ORIGIN.with(|stored| *stored.borrow_mut() = origin);
 160      Ok(())
 161  }
 162  
 163  fn load_inspector_origin() -> Result<(), String> {
 164      let origin = if let Some(origin) = query_value(INSPECTOR_QUERY_KEY)
 165          .map(|origin| normalize_origin(origin, DEFAULT_INSPECTOR_ORIGIN))
 166      {
 167          if let Some(storage) = session_storage()? {
 168              storage
 169                  .set_item(INSPECTOR_STORAGE_KEY, &origin)
 170                  .map_err(js_error)?;
 171          }
 172          origin
 173      } else if let Some(storage) = session_storage()? {
 174          storage
 175              .get_item(INSPECTOR_STORAGE_KEY)
 176              .map_err(js_error)?
 177              .map(|origin| normalize_origin(origin, DEFAULT_INSPECTOR_ORIGIN))
 178              .unwrap_or_else(|| DEFAULT_INSPECTOR_ORIGIN.to_owned())
 179      } else {
 180          DEFAULT_INSPECTOR_ORIGIN.to_owned()
 181      };
 182  
 183      INSPECTOR_ORIGIN.with(|stored| *stored.borrow_mut() = origin);
 184      Ok(())
 185  }
 186  
 187  /// Ссылка на Inspector с пробросом session token и app-server origin:
 188  /// hardcoded href терял бы token при включённом token-режиме.
 189  pub(crate) fn inspector_link_url() -> String {
 190      let origin = INSPECTOR_ORIGIN.with(|stored| stored.borrow().clone());
 191      let mut params = Vec::new();
 192      if let Some(token) = current_session_token().as_deref() {
 193          params.push(format!("token={}", encode_uri_component(token)));
 194      }
 195      params.push(format!(
 196          "server={}",
 197          encode_uri_component(&app_server_origin())
 198      ));
 199      format!("{origin}/?{}", params.join("&"))
```

### `clients/web/src/api.rs:276–286`

```text
 276  fn normalize_app_server_origin(origin: String) -> String {
 277      normalize_origin(origin, DEFAULT_APP_SERVER_ORIGIN)
 278  }
 279  
 280  fn normalize_origin(origin: String, default: &str) -> String {
 281      let origin = origin.trim().trim_end_matches('/');
 282      if origin.is_empty() {
 283          default.to_owned()
 284      } else {
 285          origin.to_owned()
 286      }
```

### `clients/inspector/src/api.rs:136–190`

```text
 136  fn load_app_server_origin() -> Result<(), String> {
 137      let origin = if let Some(origin) = query_app_server_origin() {
 138          persist_app_server_origin(&origin)?;
 139          origin
 140      } else if let Some(storage) = session_storage()? {
 141          storage
 142              .get_item(SERVER_STORAGE_KEY)
 143              .map_err(js_error)?
 144              .map(normalize_app_server_origin)
 145              .unwrap_or_else(|| DEFAULT_APP_SERVER_ORIGIN.to_owned())
 146      } else {
 147          DEFAULT_APP_SERVER_ORIGIN.to_owned()
 148      };
 149  
 150      APP_SERVER_ORIGIN.with(|stored| *stored.borrow_mut() = origin);
 151      Ok(())
 152  }
 153  
 154  fn load_chat_origin() -> Result<(), String> {
 155      let origin = if let Some(origin) = query_value(CHAT_QUERY_KEY) {
 156          let origin = normalize_origin(origin, DEFAULT_CHAT_ORIGIN);
 157          if let Some(storage) = session_storage()? {
 158              storage
 159                  .set_item(CHAT_STORAGE_KEY, &origin)
 160                  .map_err(js_error)?;
 161          }
 162          origin
 163      } else if let Some(storage) = session_storage()? {
 164          storage
 165              .get_item(CHAT_STORAGE_KEY)
 166              .map_err(js_error)?
 167              .map(|origin| normalize_origin(origin, DEFAULT_CHAT_ORIGIN))
 168              .unwrap_or_else(|| DEFAULT_CHAT_ORIGIN.to_owned())
 169      } else {
 170          DEFAULT_CHAT_ORIGIN.to_owned()
 171      };
 172  
 173      CHAT_ORIGIN.with(|stored| *stored.borrow_mut() = origin);
 174      Ok(())
 175  }
 176  
 177  /// Ссылка на chat-клиент с пробросом session token и app-server origin —
 178  /// зеркально `inspector_link_url()` в `clients/web`: hardcoded href терял бы
 179  /// token при включённом token-режиме и нестандартных портах.
 180  pub(crate) fn chat_link_url() -> String {
 181      let origin = CHAT_ORIGIN.with(|stored| stored.borrow().clone());
 182      let mut params = Vec::new();
 183      if let Some(token) = current_session_token().as_deref() {
 184          params.push(format!("token={}", encode_uri_component(token)));
 185      }
 186      params.push(format!(
 187          "server={}",
 188          encode_uri_component(&app_server_origin())
 189      ));
 190      format!("{origin}/?{}", params.join("&"))
```

## F03 · Markdown → inner_html: отсутствует фильтрация опасных URL-схем

### `clients/web/src/markdown.rs:1–19`

```text
   1  use pulldown_cmark::{Event as MarkdownEvent, Options as MarkdownOptions, Parser, html};
   2  
   3  pub(crate) fn markdown_html(text: &str) -> String {
   4      let mut options = MarkdownOptions::empty();
   5      options.insert(MarkdownOptions::ENABLE_TABLES);
   6      options.insert(MarkdownOptions::ENABLE_STRIKETHROUGH);
   7      options.insert(MarkdownOptions::ENABLE_TASKLISTS);
   8      let normalized_text = normalize_math_code_blocks(text);
   9      let (markdown_text, math_fragments) = extract_math_fragments(&normalized_text);
  10      let parser = Parser::new_ext(&markdown_text, options).map(|event| match event {
  11          MarkdownEvent::Html(raw) | MarkdownEvent::InlineHtml(raw) => MarkdownEvent::Text(raw),
  12          event => event,
  13      });
  14      let mut output = String::new();
  15      html::push_html(&mut output, parser);
  16      for (token, html) in math_fragments {
  17          output = output.replace(&token, &html);
  18      }
  19      enhance_code_blocks(&output)
```

### `clients/web/src/components/message.rs:121–142`

```text
 121  fn text_message_view(message: Memo<Option<Message>>, turn_class: &'static str) -> AnyView {
 122      let rendered_html = cached_message_html(message);
 123      view! {
 124          <article class=turn_class>
 125              <div class="task-card-header">
 126                  <span class="assistant-role">{move || {
 127                      message
 128                          .with(|message| message.as_ref().map(|message| message.role.label()))
 129                          .unwrap_or("Сообщение")
 130                  }}</span>
 131                  <div class="message-actions">
 132                      <CopyButton
 133                          text=move || current_message_text(message)
 134                          class="icon-button"
 135                          title="Скопировать markdown"
 136                      />
 137                  </div>
 138              </div>
 139              <div
 140                  class=move || current_message_content_class(message)
 141                  inner_html=move || rendered_html.get()
 142              ></div>
```

### `clients/web/Cargo.lock:1212–1229`

```text
1212  name = "pulldown-cmark"
1213  version = "0.13.4"
1214  source = "registry+https://github.com/rust-lang/crates.io-index"
1215  checksum = "e9f068eba8e7071c5f9511831b44f32c740d5adf574e990f946ddb53db2f314e"
1216  dependencies = [
1217   "bitflags",
1218   "getopts",
1219   "memchr",
1220   "pulldown-cmark-escape",
1221   "unicase",
1222  ]
1223  
1224  [[package]]
1225  name = "pulldown-cmark-escape"
1226  version = "0.11.0"
1227  source = "registry+https://github.com/rust-lang/crates.io-index"
1228  checksum = "007d8adb5ddab6f8e3f491ac63566a7d5002cc7ed73901f72057943fa71ae1ae"
1229  
```

## F04 · Ошибка многофайлового patch не сообщает о ранее выполненных изменениях

### `modules/reference/direct-patch/src/lib.rs:30–54`

```text
  30          match apply_patch(&patch.content, Path::new(cwd.as_str())) {
  31              Ok(result) => match serde_json::to_string(&result) {
  32                  Ok(json) => Ok(json.into()),
  33                  Err(error) => Err(ProcessModuleError::new(format!(
  34                      "failed to serialize PatchResult: {error}"
  35                  ))),
  36              },
  37              Err(error) => Err(ProcessModuleError::new(error)),
  38          }
  39      }
  40  }
  41  
  42  fn apply_patch(input: &str, workspace_root: &Path) -> Result<PatchResult, String> {
  43      let operations = parse_patch(input)?;
  44      if operations.is_empty() {
  45          return Err("patch must contain at least one operation".to_owned());
  46      }
  47  
  48      let workspace = canonical_workspace(workspace_root)?;
  49      let mut summaries = Vec::with_capacity(operations.len());
  50      for operation in operations {
  51          summaries.push(apply_operation(&workspace, operation)?);
  52      }
  53  
  54      Ok(PatchResult::new(true, summaries.join("; ")))
```

### `modules/reference/direct-patch/src/lib.rs:281–340`

```text
 281  fn apply_operation(workspace: &Path, operation: PatchOperation) -> Result<String, String> {
 282      match operation {
 283          PatchOperation::Add { path, lines } => {
 284              let target = writable_workspace_path(workspace, &path)?;
 285              if fs::metadata(&target).is_ok() {
 286                  return Err(format!(
 287                      "cannot add file that already exists: {}",
 288                      path.display()
 289                  ));
 290              }
 291              fs::write(&target, render_text(&lines, true))
 292                  .map_err(|error| format!("failed to write {}: {error}", target.display()))?;
 293              Ok(format!("added {}", path.display()))
 294          }
 295          PatchOperation::Update {
 296              path,
 297              move_to,
 298              hunks,
 299              no_newline_at_eof,
 300          } => {
 301              let source = existing_workspace_path(workspace, &path)?;
 302              let original = fs::read_to_string(&source)
 303                  .map_err(|error| format!("failed to read {}: {error}", source.display()))?;
 304              let updated = apply_hunks(&original, &hunks, no_newline_at_eof)?;
 305              let destination = match move_to.as_ref() {
 306                  Some(target) => writable_workspace_path(workspace, target)?,
 307                  None => source.clone(),
 308              };
 309  
 310              if destination != source && fs::metadata(&destination).is_ok() {
 311                  return Err(format!(
 312                      "move target already exists: {}",
 313                      destination.display()
 314                  ));
 315              }
 316  
 317              fs::write(&destination, updated)
 318                  .map_err(|error| format!("failed to write {}: {error}", destination.display()))?;
 319              if destination != source {
 320                  fs::remove_file(&source)
 321                      .map_err(|error| format!("failed to remove {}: {error}", source.display()))?;
 322                  return Ok(format!(
 323                      "updated {} and moved to {}",
 324                      path.display(),
 325                      move_to
 326                          .as_ref()
 327                          .expect("move target exists when destination differs")
 328                          .display()
 329                  ));
 330              }
 331  
 332              Ok(format!("updated {}", path.display()))
 333          }
 334          PatchOperation::Delete { path } => {
 335              let target = existing_workspace_path(workspace, &path)?;
 336              fs::remove_file(&target)
 337                  .map_err(|error| format!("failed to delete {}: {error}", target.display()))?;
 338              Ok(format!("deleted {}", path.display()))
 339          }
 340      }
```

## F05 · Два процесса могут писать одну сессию с независимыми session_seq

### `crates/proteus-core/src/core/session_store.rs:34–69`

```text
  34  pub struct SessionStore {
  35      session_dir: PathBuf,
  36      session_id: SessionId,
  37      directory_kind: SessionDirectoryKind,
  38      writer: Arc<Mutex<JournalWriterState>>,
  39      blob_threshold_bytes: usize,
  40  }
  41  
  42  impl SessionStore {
  43      pub fn new(config_dir: &Path, cwd: &Path, session_id: SessionId) -> Result<Self> {
  44          let workspace = encode_workspace_path(cwd)?;
  45          let session_dir = config_dir
  46              .join("sessions")
  47              .join(workspace)
  48              .join(short_session_directory_name(session_id));
  49          validate_new_session_target(&session_dir, session_id)?;
  50          let writer = writer_for_session_dir(&session_dir);
  51          Ok(Self {
  52              session_dir,
  53              session_id,
  54              directory_kind: SessionDirectoryKind::ShortNumeric,
  55              writer,
  56              blob_threshold_bytes: DEFAULT_BLOB_THRESHOLD_BYTES,
  57          })
  58      }
  59  
  60      pub fn open(session_dir: PathBuf) -> Result<Self> {
  61          let identity = resolve_session_identity(&session_dir)?;
  62          workspace_path_from_session_dir(&session_dir)?;
  63          let writer = writer_for_session_dir(&session_dir);
  64          Ok(Self {
  65              session_dir,
  66              session_id: identity.session_id,
  67              directory_kind: identity.directory_kind,
  68              writer,
  69              blob_threshold_bytes: DEFAULT_BLOB_THRESHOLD_BYTES,
```

### `crates/proteus-core/src/core/session_store.rs:473–482`

```text
 473  fn writer_for_session_dir(session_dir: &Path) -> Arc<Mutex<JournalWriterState>> {
 474      static WRITERS: OnceLock<StdMutex<HashMap<PathBuf, Arc<Mutex<JournalWriterState>>>>> =
 475          OnceLock::new();
 476      let key = canonicalize_journal_path(&journal_path(session_dir));
 477      let writers = WRITERS.get_or_init(|| StdMutex::new(HashMap::new()));
 478      let mut writers = writers.lock().expect("session journal writer map poisoned");
 479      writers
 480          .entry(key)
 481          .or_insert_with(|| Arc::new(Mutex::new(JournalWriterState::default())))
 482          .clone()
```

### `crates/proteus-core/src/core/session_journal/storage.rs:112–184`

```text
 112      let record = JournalRecord {
 113          schema_version: JOURNAL_SCHEMA_VERSION,
 114          record_id: new_record_id(),
 115          session_seq: state.next_seq,
 116          timestamp_ms: unix_timestamp_ms(),
 117          session_id,
 118          execution_id: attribution.execution_id,
 119          thread_id: attribution.thread_id,
 120          turn_id: attribution.turn_id,
 121          entry,
 122      };
 123      let mut next_validation = state.validation.clone();
 124      next_validation.apply(&record)?;
 125  
 126      let stored_payload = if payload_bytes.len() >= blob_threshold_bytes {
 127          write_blob(session_dir, &payload_bytes).await?
 128      } else {
 129          StoredPayload::Inline { value: payload }
 130      };
 131      let stored = StoredJournalRecord {
 132          schema_version: record.schema_version,
 133          record_id: record.record_id,
 134          session_seq: record.session_seq,
 135          timestamp_ms: record.timestamp_ms,
 136          session_id: record.session_id,
 137          execution_id: record.execution_id,
 138          thread_id: record.thread_id,
 139          turn_id: record.turn_id,
 140          kind,
 141          payload: stored_payload,
 142      };
 143      let mut line = serde_json::to_vec(&stored)?;
 144      line.push(b'\n');
 145      let path = journal_path(session_dir);
 146      let mut file = OpenOptions::new()
 147          .create(true)
 148          .append(true)
 149          .open(&path)
 150          .await
 151          .with_context(|| format!("failed to open {}", path.display()))?;
 152      file.write_all(&line)
 153          .await
 154          .with_context(|| format!("failed to append {}", path.display()))?;
 155      file.flush().await?;
 156      file.sync_data().await?;
 157  
 158      state.next_seq = state.next_seq.saturating_add(1);
 159      state.validation = next_validation;
 160      Ok(record)
 161  }
 162  
 163  pub(crate) fn initialize_writer_state(
 164      session_dir: &Path,
 165      session_id: SessionId,
 166      state: &mut JournalWriterState,
 167  ) -> Result<()> {
 168      if state.initialized {
 169          return Ok(());
 170      }
 171      repair_unterminated_tail(&journal_path(session_dir))?;
 172      let records = load_records(session_dir, session_id)?;
 173      let projection = JournalProjection::build(session_id, records.clone())?;
 174      let mut validation = JournalValidationState::default();
 175      for record in &records {
 176          validation.apply(record)?;
 177      }
 178      state.next_seq = records
 179          .last()
 180          .map(|record| record.session_seq.saturating_add(1))
 181          .unwrap_or(1);
 182      debug_assert_eq!(validation.history_revision(), projection.history_revision);
 183      state.validation = validation;
 184      state.initialized = true;
```

### `crates/proteus-core/src/core/session_journal/projection.rs:370–399`

```text
 370  impl JournalProjection {
 371      pub fn build(session_id: SessionId, records: Vec<JournalRecord>) -> Result<Self> {
 372          let mut state = JournalValidationState::default();
 373          let mut expected_seq = 1_u64;
 374          for record in &records {
 375              if record.schema_version != JOURNAL_SCHEMA_VERSION {
 376                  bail!(
 377                      "unsupported journal schema_version {} in record {}; expected {}",
 378                      record.schema_version,
 379                      record.record_id,
 380                      JOURNAL_SCHEMA_VERSION
 381                  );
 382              }
 383              if record.session_id != session_id {
 384                  bail!(
 385                      "journal record {} belongs to session {}, expected {}",
 386                      record.record_id,
 387                      record.session_id,
 388                      session_id
 389                  );
 390              }
 391              if record.session_seq != expected_seq {
 392                  bail!(
 393                      "journal sequence mismatch: expected {}, found {}",
 394                      expected_seq,
 395                      record.session_seq
 396                  );
 397              }
 398              expected_seq = expected_seq.saturating_add(1);
 399              state.apply(record)?;
```

### `crates/proteus-core/src/app_server.rs:660–678`

```text
 660      pub async fn launch_or_resume_latest(
 661          config: AppConfig,
 662          cwd: PathBuf,
 663          config_path: Option<&Path>,
 664      ) -> Result<AppServerHandle> {
 665          if let Some(session_dir) = latest_workspace_session_dir(config_path, &cwd)? {
 666              return Self::launch_resumed(config, cwd, config_path, session_dir).await;
 667          }
 668          Self::launch(config, cwd, config_path).await
 669      }
 670  
 671      pub async fn launch_resumed(
 672          config: AppConfig,
 673          cwd: PathBuf,
 674          config_path: Option<&Path>,
 675          session_dir: PathBuf,
 676      ) -> Result<AppServerHandle> {
 677          Self::launch_inner(config, cwd, config_path, None, Some(session_dir)).await
 678      }
```

## F06 · Полное синхронное чтение журнала перед каждым append

### `crates/proteus-core/src/core/session_journal/storage.rs:88–101`

```text
  88  pub(crate) async fn append_record(
  89      session_dir: &Path,
  90      session_id: SessionId,
  91      attribution: JournalRecordAttribution,
  92      entry: JournalEntry,
  93      blob_threshold_bytes: usize,
  94      state: &mut JournalWriterState,
  95  ) -> Result<JournalRecord> {
  96      repair_unterminated_tail(&journal_path(session_dir))?;
  97      initialize_writer_state(session_dir, session_id, state)?;
  98  
  99      let kind = entry.kind();
 100      let mut payload = entry.payload_value()?;
 101      redact_sensitive_values(&mut payload);
```

### `crates/proteus-core/src/core/session_journal/storage.rs:292–312`

```text
 292  fn repair_unterminated_tail(path: &Path) -> Result<()> {
 293      let bytes = match std::fs::read(path) {
 294          Ok(bytes) => bytes,
 295          Err(error) if error.kind() == ErrorKind::NotFound => return Ok(()),
 296          Err(error) => {
 297              return Err(error).with_context(|| format!("failed to read {}", path.display()));
 298          }
 299      };
 300      let complete_len = complete_jsonl_len(&bytes);
 301      if complete_len == bytes.len() {
 302          return Ok(());
 303      }
 304      let file = StdOpenOptions::new()
 305          .write(true)
 306          .open(path)
 307          .with_context(|| format!("failed to open {} for tail recovery", path.display()))?;
 308      file.set_len(complete_len as u64)
 309          .with_context(|| format!("failed to truncate interrupted tail in {}", path.display()))?;
 310      file.sync_data()?;
 311      Ok(())
 312  }
```

## F07 · Неподдерживаемый @@ -line,count +line,count @@ принимается с потерей позиционной семантики

### `crates/proteus-core/src/tools/patch.rs:25–35`

```text
  25      fn spec(&self) -> ToolSpec {
  26          ToolSpec::new(
  27              "apply_patch",
  28              "Apply a workspace patch through the configured PatchApplier. The default direct patcher uses Proteus internal patch format, not unified diff: do not send diff --git, ---/+++, @@ -line,count headers, or replace file:N-M commands.",
  29              json!({
  30                  "type": "object",
  31                  "description": "Patch request. For modules.patch = \"direct\", patch must use Proteus internal patch format with *** Begin Patch / *** End Patch and *** Add File, *** Update File, or *** Delete File operations. Unified diff is not accepted.",
  32                  "properties": {
  33                      "patch": {
  34                          "type": "string",
  35                          "description": "Internal patch text. Example update: *** Begin Patch\n*** Update File: src/main.rs\n@@\n-old line\n+new line\n*** End Patch"
```

### `crates/proteus-core/src/tools/patch.rs:58–65`

```text
  58              "unsupported_formats": [
  59                  "diff --git",
  60                  "--- a/file and +++ b/file unified diff headers",
  61                  "@@ -line,count +line,count @@ unified diff hunks",
  62                  "replace file:start-end"
  63              ],
  64              "example_add": "*** Begin Patch\n*** Add File: notes.txt\n+first line\n+second line\n*** End Patch",
  65              "example_update": "*** Begin Patch\n*** Update File: src/main.rs\n@@\n-old line\n+new line\n*** End Patch",
```

### `modules/reference/direct-patch/src/lib.rs:195–220`

```text
 195  fn parse_update_file(parser: &mut PatchParser<'_>, path: &str) -> Result<PatchOperation, String> {
 196      let mut move_to = None;
 197      if let Some(line) = parser.peek()
 198          && let Some(target) = line.strip_prefix("*** Move to: ")
 199      {
 200          parser.next();
 201          move_to = Some(parse_patch_path(target)?);
 202      }
 203  
 204      let mut hunks = Vec::new();
 205      let mut no_newline_at_eof = false;
 206      while let Some(line) = parser.peek() {
 207          if line == "*** End Patch" || is_file_header(line) {
 208              break;
 209          }
 210          if line == "*** End of File" {
 211              no_newline_at_eof = true;
 212              parser.next();
 213              continue;
 214          }
 215          if line.starts_with("@@") {
 216              parser.next();
 217              hunks.push(parse_hunk(parser)?);
 218              continue;
 219          }
 220          return Err(format!("expected '@@' or next patch header, got: {line}"));
```

### `modules/reference/direct-patch/src/lib.rs:365–401`

```text
 365          let Some(position) = find_subsequence(&lines, &old_lines, cursor) else {
 366              return Err("failed to match update hunk against current file content".to_owned());
 367          };
 368          let new_len = new_lines.len();
 369          lines.splice(position..position + old_lines.len(), new_lines);
 370          cursor = position + new_len;
 371      }
 372  
 373      if no_newline_at_eof {
 374          trailing_newline = false;
 375      }
 376  
 377      Ok(render_text(&lines, trailing_newline))
 378  }
 379  
 380  fn split_lines(text: &str) -> (Vec<String>, bool) {
 381      let trailing_newline = text.ends_with('\n');
 382      let lines = if text.is_empty() {
 383          Vec::new()
 384      } else {
 385          text.split_terminator('\n')
 386              .map(str::to_owned)
 387              .collect::<Vec<_>>()
 388      };
 389      (lines, trailing_newline)
 390  }
 391  
 392  fn find_subsequence(lines: &[String], needle: &[String], start: usize) -> Option<usize> {
 393      if needle.is_empty() {
 394          return Some(start.min(lines.len()));
 395      }
 396      if needle.len() > lines.len() {
 397          return None;
 398      }
 399  
 400      let last_start = lines.len() - needle.len();
 401      (start..=last_start).find(|&index| lines[index..index + needle.len()] == needle[..])
```

## F08 · Redaction по имени ключа искажает JSON Schema в canonical journal

### `crates/proteus-core/src/core/session_journal/storage.rs:99–111`

```text
  99      let kind = entry.kind();
 100      let mut payload = entry.payload_value()?;
 101      redact_sensitive_values(&mut payload);
 102      let payload_bytes = serde_json::to_vec(&payload)?;
 103      if payload_bytes.len() > MAX_PAYLOAD_BYTES {
 104          bail!(
 105              "journal payload is {} bytes, maximum is {} bytes",
 106              payload_bytes.len(),
 107              MAX_PAYLOAD_BYTES
 108          );
 109      }
 110      let entry = JournalEntry::from_kind_and_payload(kind, payload.clone())
 111          .context("redacted journal payload no longer matches its canonical DTO")?;
```

### `crates/proteus-core/src/core/session_journal/storage.rs:444–476`

```text
 444  fn redact_sensitive_values(value: &mut serde_json::Value) {
 445      match value {
 446          serde_json::Value::Object(map) => {
 447              for (key, nested) in map {
 448                  if is_sensitive_key(key) {
 449                      *nested = serde_json::Value::String("[REDACTED]".to_owned());
 450                  } else {
 451                      redact_sensitive_values(nested);
 452                  }
 453              }
 454          }
 455          serde_json::Value::Array(values) => {
 456              for nested in values {
 457                  redact_sensitive_values(nested);
 458              }
 459          }
 460          _ => {}
 461      }
 462  }
 463  
 464  fn is_sensitive_key(key: &str) -> bool {
 465      matches!(
 466          key.to_ascii_lowercase().replace('-', "_").as_str(),
 467          "authorization"
 468              | "api_key"
 469              | "access_token"
 470              | "refresh_token"
 471              | "session_token"
 472              | "password"
 473              | "secret"
 474              | "cookie"
 475              | "set_cookie"
 476      )
```

### `crates/proteus-contracts/src/domain/tool.rs:258–268`

```text
 258  #[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
 259  #[serde(deny_unknown_fields)]
 260  #[non_exhaustive]
 261  pub struct ToolSpec {
 262      pub name: String,
 263      pub description: String,
 264      pub input_schema: serde_json::Value,
 265      pub surface: ToolSurface,
 266      pub safety: ToolSafety,
 267      pub timeout_ms: Option<u64>,
 268      pub metadata: serde_json::Value,
```

### `crates/proteus-contracts/src/model_standard/canonical_request.rs:10–25`

```text
  10      model_standard::CanonicalMessage,
  11  };
  12  
  13  #[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
  14  #[non_exhaustive]
  15  pub struct CanonicalModelRequest {
  16      pub model: ModelRef,
  17      pub instructions: Vec<InstructionBlock>,
  18      pub messages: Vec<CanonicalMessage>,
  19      pub tools: Vec<ToolSpec>,
  20      pub tool_choice: ToolChoice,
  21      pub response_format: ResponseFormat,
  22      pub sampling: SamplingConfig,
  23      pub reasoning: ReasoningConfig,
  24      pub limits: ModelLimits,
  25      pub cache: CacheHints,
```

### `crates/proteus-core/src/core/session_journal/types.rs:38–43`

```text
  38  #[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
  39  #[serde(deny_unknown_fields)]
  40  pub struct ModelRequestRecorded {
  41      pub exchange_id: ExchangeId,
  42      pub request: CanonicalModelRequest,
  43  }
```
